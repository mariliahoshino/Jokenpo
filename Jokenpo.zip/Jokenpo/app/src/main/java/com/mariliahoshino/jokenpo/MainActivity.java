package com.mariliahoshino.jokenpo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    public int resQGanhou = 0, resQEmpate = 0, resQPerdeu = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void selecionadoPedra(View view){
        this.opcaoSelecionada("pedra");

    }

    public void selecionadoPapel(View view){
        this.opcaoSelecionada("papel");

    }

    public void selecionadoTesoura(View view){
        this.opcaoSelecionada("tesoura");

    }

    public void opcaoSelecionada(String escolhaUsuario){

        ImageView imageResultado = findViewById(R.id.imageResultado);
        TextView textoResultado = findViewById(R.id.textResultado);
        TextView textoQGanhou = findViewById(R.id.textQGanhou);
        TextView textoQEmpate = findViewById(R.id.textQEmpate);
        TextView textoQPerdeu = findViewById(R.id.textQPerdeu);

        int numero = new Random().nextInt(3);

        String[] opcoes = {"pedra", "papel", "tesoura"};
        String escolhaApp = opcoes[ numero ];

        switch (escolhaApp){
            case "pedra":
                imageResultado.setImageResource(R.drawable.pedra);
                break;

            case "papel":
                imageResultado.setImageResource(R.drawable.papel);
                break;

            case "tesoura":
                imageResultado.setImageResource(R.drawable.tesoura);
                break;
        }

        if(
                (escolhaApp =="tesoura" && escolhaUsuario == "papel") ||
                        (escolhaApp =="papel" && escolhaUsuario == "pedra") ||
                        (escolhaApp =="pedra" && escolhaUsuario == "tesoura")) {   //App ganhador
            textoResultado.setText("Você perdeu :(");
            resQPerdeu++;
            //Log.i(resQPerdeu, "perdeu");
            textoQPerdeu.setText(String.valueOf(resQPerdeu));

        }else if(
                (escolhaUsuario =="tesoura" && escolhaApp == "papel") ||
                        (escolhaUsuario =="papel" && escolhaApp == "pedra") ||
                        (escolhaUsuario =="pedra" && escolhaApp == "tesoura")) { //Usuário ganhador
            textoResultado.setText("Você ganhou :)");
            resQGanhou++;
            //String.valueOf()
            textoQGanhou.setText(String.valueOf(resQGanhou));

        }else{  //empate
            textoResultado.setText("Empatamos :/");
            resQEmpate++;
            //textoQEmpate.setText(resQEmpate);
            textoQEmpate.setText(String.valueOf(resQEmpate));
        }

        //System.out.println( "opcao " + escolhaApp);

    }
}